
jQuery(document).ready(function() {

    /*
        Background slideshow
    */
    $('#banner').backstretch([
      "https://lh3.googleusercontent.com/BDPiEexNAIDeC2jkYW5fCgTHSFYnDvPhU4ewrtLEgRLp4kaLYN3rezvEtVMNJhL_pAFgoYKV9Xupuw=w1000"
    , "https://lh3.googleusercontent.com/guucnA1w65TPAj2TqVvRLF_lszXVZKpIecL1Qnv07F-FQ11zI3zYtfIOXkNzLT3aht2lStbtDLKUFg=w1000"
    , "https://lh3.googleusercontent.com/9_xWly7aPkTyOdkrCk4qTPPG4zWHhzNoBlunM9S2hiGEWhw1fc0uPkANuvBVijJcq2tdHShf9HoQag=w1000"
    , "https://lh3.googleusercontent.com/oq05wu9rNToMOswRPg9X_K-kSP7ZIfR8wFOFmrUDjIFn-Fa57Eq_MkYZwcdVBkWbeoRaFwkY480Z4A=w1000"
    ], {duration: 3000, fade: 750});
});
