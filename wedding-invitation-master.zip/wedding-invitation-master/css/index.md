Directory access is forbidden.
